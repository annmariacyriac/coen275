package com.project.dao;

import com.project.model.Movie;

public interface MovieDao {

	public Movie getMovieDetails(int movieId) ;

}
