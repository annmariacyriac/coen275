package com.project.dao;

import com.project.model.BookShow;

public interface BookingDao{

	public int bookShow(BookShow bookShow) ;

}
